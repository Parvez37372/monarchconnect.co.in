<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Businesses - Monarch Connect</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    background:#000;
    color:#fff;
    font-family:Arial, sans-serif;
}

.container{
    width:90%;
    max-width:1200px;
    margin:50px auto;
}

h1{
    color:#C8A45B;
    text-align:center;
    margin-bottom:40px;
}

.business-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
    gap:25px;
}

.business-card{
    background:#111;
    border:1px solid #292929;
    padding:25px;
    border-radius:12px;
    transition:.3s;
}

.business-card:hover{
    border-color:#C8A45B;
    transform:translateY(-5px);
}

.business-card h2{
    color:#C8A45B;
    margin-bottom:15px;
}

.business-card p{
    color:#bbb;
    margin:8px 0;
}

.view-btn{
    display:inline-block;
    margin-top:20px;
    padding:12px 20px;
    background:#C8A45B;
    color:#000;
    text-decoration:none;
    border-radius:6px;
    font-weight:bold;
}

.view-btn:hover{
    background:#fff;
}

</style>
</head>

<body>

<div class="container">

<h1>Our Businesses</h1>

<div class="business-grid">



<div class="business-card">

<h2>
monarch</h2>

<p>
<strong>Business No:</strong>
145</p>

<p>
<strong>Phone:</strong>
8868848218</p>

<a
    class="view-btn"
    href="business-profile.php?id=2"
>
    View Profile
</a>

</div>


<div class="business-card">

<h2>
monarch</h2>

<p>
<strong>Business No:</strong>
0114</p>

<p>
<strong>Phone:</strong>
8868848218</p>

<a
    class="view-btn"
    href="business-profile.php?id=1"
>
    View Profile
</a>

</div>



</div>

</div>

</body>
</html>