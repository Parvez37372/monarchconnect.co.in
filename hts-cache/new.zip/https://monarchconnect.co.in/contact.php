<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Monarch Connect - Header</title>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="icon" href="assets/images/monarch-fav.png" type="image/png">

<style>
* { margin:0; padding:0; box-sizing:border-box; }
html { scroll-behavior:smooth; }
body { background:#050505; color:#fff; font-family:Arial,Helvetica,sans-serif; }
a { color:inherit; text-decoration:none; }

/* HEADER ONLY */
.main-header {
    position:fixed; top:0; left:0; width:100%; height:100px;
    display:flex; align-items:center; justify-content:space-between;
    padding:0 55px; z-index:500; background:transparent;
    transition:background .4s ease, box-shadow .4s ease, backdrop-filter .4s ease;
}
.main-header.scrolled { background:#050505; box-shadow:0 5px 25px rgba(0,0,0,.65); backdrop-filter:blur(8px); }
.main-header::after {
    content:""; position:absolute; left:55px; right:55px; bottom:0; height:1px;
    background:rgba(255,255,255,.65); transition:all .4s ease;
}
.main-header.scrolled::after { left:0; right:0; background:rgba(255,255,255,.75); }

.menu-btn {
    position:relative; width:80px; height:40px; display:flex; align-items:center;
    padding:0 0 0 38px; background:transparent; border:0; color:#fff;
    font-size:12px; font-weight:400; letter-spacing:2px; cursor:pointer; z-index:510;
}
.menu-btn span { position:absolute; left:0; width:25px; height:1px; background:#fff; display:block; transition:transform .3s ease,width .3s ease; }
.menu-btn span:nth-child(1) { top:8px; }
.menu-btn span:nth-child(2) { top:15px; }
.menu-btn span:nth-child(3) { top:22px; }
.menu-btn:hover span:nth-child(1) { width:30px; }
.menu-btn:hover span:nth-child(3) { width:20px; }

.logo { position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); display:flex; align-items:center; justify-content:center; z-index:505; }
.logo img { width:150px; height:150px; display:block; object-fit:contain; }

.contact-btn {
    display:inline-flex; align-items:center; justify-content:center; padding:12px 24px;
    border:1px solid #fff; border-radius:20px; color:#fff; font-size:16px;
    font-weight:400; letter-spacing:2px; transition:all .35s ease; z-index:505;
}
.contact-btn:hover { background:#fff; border-color:#fff; color:#000; }

/* SLIDE-OUT NAVIGATION */
.side-menu {
    position:fixed; top:0; left:-500px; width:370px; height:100vh;
    padding:120px 45px 40px; background:#080808; border-right:1px solid rgba(255,255,255,.45);
    z-index:700; overflow-y:auto; transition:left .45s cubic-bezier(.77,0,.175,1);
}
.side-menu.active { left:0; }
.close-btn {
    position:absolute; top:28px; right:30px; width:42px; height:42px;
    display:flex; align-items:center; justify-content:center; padding:0;
    background:transparent; border:0; color:#fff; font-size:35px; font-weight:200;
    line-height:1; cursor:pointer; transition:all .3s ease;
}
.close-btn:hover { transform:rotate(90deg); }
.side-menu nav { display:flex; flex-direction:column; }
.side-menu nav a {
    display:block; padding:18px 0; border-bottom:1px solid rgba(255,255,255,.08);
    color:#fff; font-size:17px; font-weight:400; letter-spacing:2px; transition:all .3s ease;
}
.side-menu nav a:first-child { border-top:1px solid rgba(255,255,255,.08); }
.side-menu nav a:hover { padding-left:10px; color:#fff; }
.menu-overlay {
    position:fixed; inset:0; background:rgba(0,0,0,.72); z-index:650;
    opacity:0; visibility:hidden; pointer-events:none; transition:opacity .35s ease,visibility .35s ease;
}
.menu-overlay.active { opacity:1; visibility:visible; pointer-events:auto; }

@media (max-width:900px) {
    .main-header { height:90px; padding:0 30px; }
    .main-header::after { left:30px; right:30px; }
    .main-header.scrolled::after { left:0; right:0; }
    .logo img { width:125px; height:125px; }
}
@media (max-width:600px) {
    .main-header { height:80px; padding:0 18px; }
    .main-header::after { left:18px; right:18px; }
    .main-header.scrolled::after { left:0; right:0; }
    .logo img { width:100px; height:100px; }
    .menu-btn { width:75px; height:36px; padding-left:30px; font-size:9px; letter-spacing:1.5px; }
    .menu-btn span { width:20px; }
    .menu-btn span:nth-child(1) { top:7px; }
    .menu-btn span:nth-child(2) { top:14px; }
    .menu-btn span:nth-child(3) { top:21px; }
    .contact-btn { padding:9px 13px; font-size:13px; letter-spacing:1px; }
    .side-menu { left:-90%; width:85%; padding:100px 30px 30px; }
    .side-menu.active { left:0; }
    .side-menu nav a { padding:16px 0; font-size:15px; }
    .close-btn { top:22px; right:22px; font-size:32px; }
}
@media (max-width:380px) {
    .main-header { padding:0 14px; }
    .main-header::after { left:14px; right:14px; }
    .logo img { width:85px; height:85px; }
    .menu-btn { width:70px; padding-left:27px; font-size:8px; }
    .menu-btn span { width:18px; }
    .contact-btn { padding:8px 10px; font-size:12px; }
}
</style>
</head>
<body>

<header class="main-header" id="mainHeader">
    <button class="menu-btn" id="menuBtn" type="button" aria-label="Open menu" aria-expanded="false">
        <span></span><span></span><span></span>
    </button>
    <a href="/index.php" class="logo" aria-label="Monarch Connect Home">
        <img src="/assets/images/logo.png" alt="Monarch Connect">
    </a>
    <a href="https://monarchconnect.co.in/account/" class="contact-btn" aria-label="Account">
        <i class="fa fa-user" aria-hidden="true"></i>
    </a>
</header>

<div class="side-menu" id="sideMenu" aria-hidden="true">
    <button class="close-btn" id="closeBtn" type="button" aria-label="Close menu">&times;</button>
    <nav>
        <a href="/index.php">Home</a>
        <a href="/about.php">About</a>
        <a href="/blogs.php">Blog</a>
        <a href="/contact.php">Contact</a>
    </nav>
</div>
<div class="menu-overlay" id="menuOverlay"></div>

<script>
const menuBtn = document.getElementById('menuBtn');
const closeBtn = document.getElementById('closeBtn');
const sideMenu = document.getElementById('sideMenu');
const menuOverlay = document.getElementById('menuOverlay');
const header = document.getElementById('mainHeader');

function openMenu() {
    sideMenu.classList.add('active');
    menuOverlay.classList.add('active');
    sideMenu.setAttribute('aria-hidden', 'false');
    menuBtn.setAttribute('aria-expanded', 'true');
}
function closeMenu() {
    sideMenu.classList.remove('active');
    menuOverlay.classList.remove('active');
    sideMenu.setAttribute('aria-hidden', 'true');
    menuBtn.setAttribute('aria-expanded', 'false');
}
menuBtn.addEventListener('click', openMenu);
closeBtn.addEventListener('click', closeMenu);
menuOverlay.addEventListener('click', closeMenu);
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') closeMenu();
});
function checkHeaderScroll() {
    header.classList.toggle('scrolled', window.scrollY > 50);
}
window.addEventListener('scroll', checkHeaderScroll);
checkHeaderScroll();
</script>

</body>
</html>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Contact Us | Monarch Connect</title>

    <!-- FONT AWESOME -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<style>

/* =================================================
   RESET
================================================= */* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    background: #050505;
    color: #fff;
    font-family: Arial, Helvetica, sans-serif;
    overflow-x: hidden;
}

a {
    text-decoration: none;
    color: inherit;
}

/* =================================================
   CONTACT HERO
================================================= */

.contact-hero {
    min-height: 70vh;

    display: flex;
    align-items: center;

    padding: 150px 8% 100px;

    background:
        linear-gradient(
            90deg,
            rgba(0,0,0,.94),
            rgba(0,0,0,.70),
            rgba(0,0,0,.92)
        ),
        url("assets/images/contact-hero.jpg");

    background-size: cover;
    background-position: center;
}

.contact-hero-content {
    max-width: 850px;
}

.contact-label {
    color: #d0d0d0;

    font-size: 12px;

    letter-spacing: 4px;
}

.contact-hero h1 {
    font-size: clamp(55px, 7vw, 100px);

    line-height: .95;

    font-weight: 300;

    margin: 25px 0;
}

.contact-hero h1 span {
    color: #d6d6d6;
}

.contact-hero p {
    max-width: 600px;

    color: #aaa;

    font-size: 16px;

    line-height: 1.8;
}


/* =================================================
   CONTACT MAIN
================================================= */

.contact-section {
    padding: 110px 8%;
    margin:50px;

    display: grid;

    grid-template-columns: 1fr 1.15fr;

    gap: 90px;

    align-items: start;
}


/* =================================================
   LEFT CONTENT
================================================= */

.contact-info {
    padding-top: 10px;
}

.section-tag {
    color: #cfcfcf;

    font-size: 12px;

    letter-spacing: 4px;
}

.contact-info h2 {
    font-size: 55px;

    line-height: 1.05;

    font-weight: 300;

    margin: 22px 0 25px;
}

.contact-info h2 span {
    color: #d6d6d6;
}

.contact-info > p {
    color: #888;

    max-width: 480px;

    line-height: 1.9;

    font-size: 15px;

    margin-bottom: 45px;
}


/* CONTACT DETAILS */

.contact-details {
    display: flex;
    flex-direction: column;

    gap: 28px;
}

.contact-detail {
    display: flex;

    align-items: center;

    gap: 20px;

    padding-bottom: 25px;

    border-bottom: 1px solid #202020;
}

.contact-icon {
    width: 48px;
    height: 48px;

    border: 1px solid #777;

    border-radius: 50%;

    display: flex;
    align-items: center;
    justify-content: center;

    color: #fff;

    font-size: 16px;

    flex-shrink: 0;

    transition: .3s;
}

.contact-detail:hover .contact-icon {
    border-color: #fff;
    background: #fff;
    color: #050505;
}

.contact-detail h4 {
    color: #fff;

    font-size: 13px;

    font-weight: 400;

    letter-spacing: 1px;

    margin-bottom: 7px;
}

.contact-detail p,
.contact-detail a {
    color: #777;

    font-size: 13px;

    line-height: 1.6;

    transition: .3s;
}

.contact-detail a:hover {
    color: #fff;
}


/* =================================================
   FORM
================================================= */

.contact-form-box {
    background: #0a0a0a;

    border: 1px solid #252525;

    padding: 45px;
}

.contact-form-box h3 {
    font-size: 28px;

    font-weight: 400;

    margin-bottom: 10px;
}

.contact-form-box > p {
    color: #777;

    font-size: 13px;

    line-height: 1.7;

    margin-bottom: 35px;
}

.contact-form {
    display: flex;

    flex-direction: column;

    gap: 20px;
}


/* TWO INPUTS */

.form-row {
    display: grid;

    grid-template-columns: 1fr 1fr;

    gap: 18px;
}

.form-group {
    display: flex;

    flex-direction: column;

    gap: 9px;
}

.form-group label {
    color: #aaa;

    font-size: 11px;

    letter-spacing: 1px;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;

    background: #050505;

    border: 1px solid #252525;

    outline: none;

    color: #fff;

    padding: 15px;

    font-family: inherit;

    font-size: 13px;

    transition: .3s;
}

.form-group input,
.form-group select {
    height: 50px;
}

.form-group textarea {
    height: 140px;

    resize: vertical;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    border-color: #fff;

    box-shadow:
        0 0 0 2px rgba(255,255,255,.05);
}

.form-group select {
    appearance: none;

    cursor: pointer;
}


/* SUBMIT */

.submit-btn {
    margin-top: 10px;

    width: 100%;

    padding: 17px;

    border: 1px solid #fff;

    background: transparent;

    color: #fff;

    font-size: 11px;

    letter-spacing: 3px;

    cursor: pointer;

    transition: .3s;
}

.submit-btn:hover {
    background: #fff;

    color: #050505;
}


/* =================================================
   BOTTOM CTA
================================================= */

.contact-cta {
    text-align: center;

    padding: 100px 20px;

    background: #090909;

    border-top: 1px solid #181818;
}

.contact-cta .section-tag {
    display: block;

    margin-bottom: 20px;
}

.contact-cta h2 {
    font-size: 55px;

    font-weight: 300;

    line-height: 1.05;

    margin-bottom: 20px;
}

.contact-cta h2 span {
    color: #d6d6d6;
}

.contact-cta p {
    color: #777;

    font-size: 14px;

    margin-bottom: 30px;
}

.cta-btn {
    display: inline-flex;

    padding: 14px 28px;

    border: 1px solid #fff;

    color: #fff;

    font-size: 11px;

    letter-spacing: 2px;

    transition: .3s;
}

.cta-btn:hover {
    background: #fff;

    color: #050505;
}


/* =================================================
   TABLET
================================================= */

@media (max-width: 1000px) {

    .contact-section {
        grid-template-columns: 1fr;

        gap: 60px;
    }
}


/* =================================================
   MOBILE
================================================= */

@media (max-width: 650px) 
    /* HERO */

    .contact-hero {
        min-height: 70vh;

        padding: 120px 22px 80px;
    }

    .contact-hero h1 {
        font-size: 52px;
    }

    .contact-hero p {
        font-size: 14px;
    }


    /* CONTACT */

    .contact-section {
        padding: 80px 22px;

        gap: 55px;
    }

    .contact-info h2 {
        font-size: 42px;
    }

    .contact-info > p {
        font-size: 14px;
    }


    /* FORM */

    .contact-form-box {
        padding: 28px 20px;
    }

    .contact-form-box h3 {
        font-size: 24px;
    }

    .form-row {
        grid-template-columns: 1fr;
    }


    /* CTA */

    .contact-cta {
        padding: 80px 20px;
    }

    .contact-cta h2 {
        font-size: 42px;
    }

}


/* =================================================
   SMALL MOBILE
================================================= */

@media (max-width: 420px) {

    .contact-hero h1 {
        font-size: 45px;
    }

    .contact-info h2 {
        font-size: 36px;
    }

    .contact-form-box {
        padding: 24px 16px;
    }

    .side-menu {
        padding-left: 24px;
        padding-right: 24px;
    }

}</style>

</head>


<body>


<!-- =================================================
     CONTACT HERO
================================================= -->

<section class="contact-hero">

    <div class="contact-hero-content">

        <span class="contact-label">
            GET IN TOUCH
        </span>

        <h1>
            Let's Build
            <br>
            <span>Something Great.</span>
        </h1>

        <p>
            Have a project in mind? Tell us what you're looking
            to build, renovate or transform. Our team is ready
            to hear your ideas.
        </p>

    </div>

</section>


<!-- =================================================
     CONTACT SECTION
================================================= -->

<section class="contact-section">


    <!-- LEFT -->

    <div class="contact-info">

        <span class="section-tag">
            CONTACT MONARCH CONNECT
        </span>

        <h2>
            Start A
            <br>
            <span>Conversation.</span>
        </h2>

        <p>
            Whether you're planning a new home, renovating
            an existing space or building a modern office,
            we're here to help you take the next step.
        </p>


        <div class="contact-details">


            <div class="contact-detail">

                <div class="contact-icon">
                    <i class="fa fa-map-marker"></i>
                </div>

                <div>

                    <h4>
                        LOCATION
                    </h4>

                    <p>
                        Delhi, India
                    </p>

                </div>

            </div>


            <div class="contact-detail">

                <div class="contact-icon">
                    <i class="fa fa-envelope"></i>
                </div>

                <div>

                    <h4>
                        EMAIL
                    </h4>

                    <a href="mailto:info@monarchconnect.in">
                        info@monarchconnect.in
                    </a>

                </div>

            </div>


            <div class="contact-detail">

                <div class="contact-icon">
                    <i class="fa fa-phone"></i>
                </div>

                <div>

                    <h4>
                        PHONE
                    </h4>

                    <a href="tel:+91 8800391355">
                        +91 8800391355
                    </a>

                </div>

            </div>


            <div class="contact-detail">

                <div class="contact-icon">
                    <i class="fa fa-clock-o"></i>
                </div>

                <div>

                    <h4>
                        WORKING HOURS
                    </h4>

                    <p>
                        Mon - Sat &nbsp; | &nbsp; 9:00 AM - 7:00 PM
                    </p>

                </div>

            </div>

        </div>

    </div>


    <!-- RIGHT FORM -->

    <div class="contact-form-box">

        <h3>
            Tell Us About Your Project
        </h3>

        <p>
            Fill in the details below and we'll get back
            to you as soon as possible.
        </p>


        <form class="contact-form"
              action="#"
              method="post">


            <div class="form-row">

                <div class="form-group">

                    <label>
                        YOUR NAME
                    </label>

                    <input
                        type="text"
                        name="name"
                        placeholder="Enter your name"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>
                        PHONE NUMBER
                    </label>

                    <input
                        type="tel"
                        name="phone"
                        placeholder="Enter phone number"
                        required
                    >

                </div>

            </div>


            <div class="form-row">

                <div class="form-group">

                    <label>
                        EMAIL ADDRESS
                    </label>

                    <input
                        type="email"
                        name="email"
                        placeholder="Enter your email"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>
                        PROJECT TYPE
                    </label>

                    <select name="project_type">

                        <option value="">
                            Select project
                        </option>

                        <option>
                            Home Construction
                        </option>

                        <option>
                            Home Renovation
                        </option>

                        <option>
                            Office Construction
                        </option>

                        <option>
                            Villa Project
                        </option>

                    </select>

                </div>

            </div>


            <div class="form-group">

                <label>
                    PROJECT LOCATION
                </label>

                <input
                    type="text"
                    name="location"
                    placeholder="Enter project location"
                >

            </div>


            <div class="form-group">

                <label>
                    YOUR MESSAGE
                </label>

                <textarea
                    name="message"
                    placeholder="Tell us about your project..."
                    required
                ></textarea>

            </div>


            <button
                type="submit"
                class="submit-btn">

                SEND PROJECT ENQUIRY

            </button>

        </form>

    </div>

</section>


<!-- =================================================
     CTA
================================================= -->

<section class="contact-cta">

    <span class="section-tag">
        MONARCH CONNECT
    </span>

    <h2>
        Your Idea.
        <br>
        <span>Our Craft.</span>
    </h2>

    <p>
        Let's create a space that makes your vision real.
    </p>

    <a href="mailto:info@monarchconnect.in"
       class="cta-btn">

        EMAIL US &nbsp; ↗

    </a>

</section>

<!-- =========================================================
     FOOTER
========================================================= -->

<footer class="main-footer">

    <div class="footer-main">

        <!-- ================= BRAND ================= -->

        <div class="footer-brand">

            <a href="/index.php" class="footer-logo">

                <img
                    src="/assets/images/logo.png"
                    alt="Monarch Connect Logo"
                >

            </a>

            <p>
                Make Your Own Mark With Monarch.
                Building ideas, creating possibilities
                and turning visions into reality.
            </p>

            <div class="footer-social">

                <a href="#" aria-label="Instagram">
                   <i class="fa fa-instagram"></i>
                </a>

                <a href="#" aria-label="Facebook">
                   <i class="fa fa-facebook"></i>
                </a>

                <a href="#" aria-label="YouTube">
                    <i class="fa fa-youtube"></i>
                </a>

                <a href="#" aria-label="LinkedIn">
                   <i class="fa fa-linkedin"></i>
                </a>

            </div>

        </div>



        <!-- ================= QUICK LINKS ================= -->

        <div class="footer-column">

            <h3>QUICK LINKS</h3>

            <a href="index.php">Home</a>

            <a href="about.php">About</a>

            <a href="#services">Services</a>

            <a href="#work">Our Work</a>

            <a href="contact.php">Contact</a>

        </div>



        <!-- ================= SERVICES ================= -->

        <div class="footer-column">

            <h3>SERVICES</h3>

            <a href="/our-services.php">Construction</a>
            <a href="/read.php">Read Me</a>

        </div>



        <!-- ================= CONTACT ================= -->

        <div class="footer-column footer-contact">

            <h3>CONTACT</h3>

            <a href="tel:+91 8800391355">
                +91 8800391355
            </a>

            <a href="monarch@info.monarchconnect.co.in">
                monarch@info.monarchconnect.co.in
            </a>

            <p>
                India
            </p>

            <a
                href="contact.php"
                class="footer-contact-btn"
            >
                GET IN TOUCH
                <span>→</span>
            </a>

        </div>

    </div>



    <!-- ================= FOOTER LINE ================= -->

    <div class="footer-line"></div>



    <!-- ================= BOTTOM ================= -->

    <div class="footer-bottom">

        <p>
            © <span id="footerYear"></span>
            Monarch Connect. All Rights Reserved.    &nbsp;<spna style="color:black"> Developed By Parvez Ahmad (<a href="https://www.google.com/search?q=parvez3737&oq=Parvez3737&gs_lcrp=EgZjaHJvbWUqBggAEEUYOzIGCAAQRRg7MgcIARAAGO8FMgcIAhAAGO8FMgcIAxAAGO8FMgcIBBAAGO8FMgcIBRAAGO8F0gEIMzQ5MmowajeoAgiwAgHxBRLQ5u5pQtVN8QUS0ObuaULVTQ&sourceid=chrome&source=chrome.ob&ie=UTF-8">Parvez3737</spna></a>
        </p>

        <div class="footer-bottom-links">

            <a href="privacy-policy.php">
                Privacy Policy
            </a>

            <a href="terms-and-conditions.php">
                Terms & Conditions
            </a>

        </div>

    </div>

</footer>
<style>/* =========================================================
   PREMIUM FOOTER — BLACK + WHITE + LIGHT GREY
========================================================= */

.main-footer {
    position: relative;
    background: #050505;
    color: #ffffff;
    padding: 85px 7% 25px;
    overflow: hidden;
}

/* =========================================================
   TOP LIGHT-GREY LINE
========================================================= */

.main-footer::before {
    content: "";
    position: absolute;
    top: 0;
    left: 7%;
    right: 7%;
    height: 1px;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(235,235,235,.75),
        transparent
    );
}

/* =========================================================
   FOOTER MAIN
========================================================= */

.footer-main {
    max-width: 1300px;
    margin: auto;
    display: grid;
    grid-template-columns: 2fr 1fr 1fr 1.3fr;
    gap: 60px;
}

/* =========================================================
   BRAND
========================================================= */

.footer-brand {
    max-width: 340px;
}

.footer-logo {
    display: inline-block;
    margin-bottom: 22px;
}

.footer-logo img {
    width: 125px;
    height: 125px;
    object-fit: contain;
    display: block;
}

.footer-brand > p {
    max-width: 320px;
    margin: 0;
    color: #a6a6a6;
    font-size: 13px;
    line-height: 1.9;
    letter-spacing: .4px;
}

/* =========================================================
   SOCIAL
========================================================= */

.footer-social {
    display: flex;
    gap: 10px;
    margin-top: 28px;
}

.footer-social a {
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;

    border: 1px solid rgba(210,210,210,.45);

    color: #e6e6e6;
    font-size: 15px;
    letter-spacing: 1px;
    text-decoration: none;

    transition: all .3s ease;
}

.footer-social a:hover {
    background: #ffffff;
    border-color: #ffffff;
    color: #000000;
    transform: translateY(-4px);
}

/* =========================================================
   COLUMNS
========================================================= */

.footer-column {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
}

.footer-column h3 {
    position: relative;
    margin: 12px 0 28px;

    color: #f5f5f5;
    font-size: 11px;
    font-weight: 400;
    letter-spacing: 4px;
}

.footer-column h3::after {
    content: "";
    display: block;
    width: 25px;
    height: 1px;
    margin-top: 11px;

    background: #d0d0d0;

    transition: width .3s ease;
}

.footer-column:hover h3::after {
    width: 45px;
}

.footer-column > a {
    margin-bottom: 14px;

    color: #9a9a9a;
    font-size: 15px;
    text-decoration: none;

    transition:
        color .3s ease,
        transform .3s ease;
}

.footer-column > a:hover {
    color: #ffffff;
    transform: translateX(5px);
}

/* =========================================================
   CONTACT
========================================================= */

.footer-contact p {
    margin: 0 0 22px;
    color: #999999;
    font-size: 14px;
}

.footer-contact-btn {
    display: inline-flex !important;
    align-items: center;
    gap: 13px;

    margin-top: 5px;
    padding: 11px 18px;

    border: 1px solid rgba(225,225,225,.55);

    color: #eeeeee !important;

    font-size: 9px !important;
    letter-spacing: 2px;

    transition: all .3s ease !important;
}

.footer-contact-btn span {
    font-size: 16px;
    transition: transform .3s ease;
}

.footer-contact-btn:hover {
    background: #ffffff;
    border-color: #ffffff;
    color: #000000 !important;
    transform: translateX(0) !important;
}

.footer-contact-btn:hover span {
    transform: translateX(5px);
}

/* =========================================================
   LINE
========================================================= */

.footer-line {
    max-width: 1300px;
    height: 1px;
    margin: 65px auto 22px;

    background: linear-gradient(
        90deg,
        transparent,
        rgba(220,220,220,.16),
        transparent
    );
}

/* =========================================================
   BOTTOM
========================================================= */

.footer-bottom {
    max-width: 1300px;
    margin: auto;

    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
}

.footer-bottom p {
    margin: 0;
    color: #666666;
    font-size: 10px;
    letter-spacing: .5px;
}

.footer-bottom-links {
    display: flex;
    gap: 25px;
}

.footer-bottom-links a {
    color: #666666;
    font-size: 10px;
    text-decoration: none;
    transition: color .3s ease;
}

.footer-bottom-links a:hover {
    color: #ffffff;
}

/* =========================================================
   TABLET
========================================================= */

@media (max-width: 950px) {

    .main-footer {
        padding: 75px 5% 25px;
    }

    .footer-main {
        grid-template-columns: repeat(2, 1fr);
        gap: 50px 40px;
    }

    .footer-brand {
        max-width: 100%;
    }
}

/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 600px) {

    .main-footer {
        padding: 65px 25px 25px;
    }

    .main-footer::before {
        left: 25px;
        right: 25px;
    }

    .footer-main {
        grid-template-columns: 1fr;
        gap: 42px;
    }

    .footer-brand {
        max-width: 100%;
        text-align: center;
    }

    .footer-logo {
        margin-bottom: 18px;
    }

    .footer-logo img {
        width: 105px;
        height: 105px;
        margin: auto;
    }

    .footer-brand > p {
        margin: auto;
        font-size: 12px;
    }

    .footer-social {
        justify-content: center;
    }

    .footer-column {
        align-items: center;
        text-align: center;
    }

    .footer-column h3 {
        margin-top: 0;
    }

    .footer-column > a:hover {
        transform: translateY(-2px);
    }

    .footer-contact-btn {
        margin-top: 8px;
    }

    .footer-bottom {
        flex-direction: column;
        text-align: center;
        gap: 15px;
    }

    .footer-bottom-links {
        flex-wrap: wrap;
        justify-content: center;
        gap: 15px;
    }
    
}
.footer-bottom p a,
.footer-bottom p a:hover,
.footer-bottom p a:focus,
.footer-bottom p a:visited {
    text-decoration: none;
    color: inherit;
}
</style>
<script>
    javascript
/* =========================================================
   FOOTER YEAR
========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    const year =
        document.getElementById("footerYear");

    if (year) {

        year.textContent =
            new Date().getFullYear();

    }

});

</script>
<!-- =================================================
     MENU JAVASCRIPT
================================================= -->

<script>

const menuBtn =
    document.getElementById("menuBtn");

const closeMenu =
    document.getElementById("closeMenu");

const sideMenu =
    document.getElementById("sideMenu");

const menuOverlay =
    document.getElementById("menuOverlay");


menuBtn.addEventListener("click", function () {

    sideMenu.classList.add("active");

    menuOverlay.classList.add("active");

    document.body.style.overflow = "hidden";

});


closeMenu.addEventListener("click", function () {

    sideMenu.classList.remove("active");

    menuOverlay.classList.remove("active");

    document.body.style.overflow = "";

});


menuOverlay.addEventListener("click", function () {

    sideMenu.classList.remove("active");

    menuOverlay.classList.remove("active");

    document.body.style.overflow = "";

});


document.querySelectorAll(".side-menu a").forEach(function(link) {

    link.addEventListener("click", function() {

        sideMenu.classList.remove("active");

        menuOverlay.classList.remove("active");

        document.body.style.overflow = "";

    });

});

</script>


</body>
</html>
