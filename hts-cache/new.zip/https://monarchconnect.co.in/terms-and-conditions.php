```html
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Terms & Conditions | Monarch Connect</title>

    <link rel="stylesheet" href="style.css">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="icon"
          type="image/png"
          href="assets/images/f.png">

    <style>

        /* =================================================
           RESET
        ================================================= */

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            background: #050505;
            color: #fff;
            font-family: Arial, Helvetica, sans-serif;
            overflow-x: hidden;
        }

        a {
            text-decoration: none;
            color: inherit;
        }


        /* =================================================
           HEADER
        ================================================= */

        .main-header {

            position: fixed;

            top: 0;
            left: 0;

            width: 100%;
            height: 100px;

            display: flex;

            align-items: center;

            justify-content: space-between;

            padding: 0 55px;

            z-index: 1000;

            background: #050505;

            border-bottom: 1px solid rgba(255,255,255,.25);

            transition: .4s ease;
        }


        .main-header::after {

            content: "";

            position: absolute;

            left: 55px;
            right: 55px;

            bottom: 0;

            height: 1px;

            background: rgba(255,255,255,.55);
        }


        /* =================================================
           MENU BUTTON
        ================================================= */

        .menu-btn {

            position: relative;

            width: 80px;
            height: 40px;

            display: flex;

            align-items: center;

            padding: 0 0 0 38px;

            background: transparent;

            border: none;

            color: #fff;

            font-size: 12px;

            letter-spacing: 2px;

            cursor: pointer;

            z-index: 60;
        }


        .menu-btn span {

            position: absolute;

            left: 0;

            width: 25px;
            height: 1px;

            background: #fff;

            display: block;

            transition: .3s ease;
        }


        .menu-btn span:nth-child(1) {
            top: 8px;
        }

        .menu-btn span:nth-child(2) {
            top: 15px;
        }

        .menu-btn span:nth-child(3) {
            top: 22px;
        }


        .menu-btn:hover span:nth-child(1) {
            width: 30px;
        }

        .menu-btn:hover span:nth-child(3) {
            width: 20px;
        }


        /* =================================================
           LOGO
        ================================================= */

        .logo {

            position: absolute;

            top: 50%;
            left: 50%;

            transform: translate(-50%, -50%);

            display: flex;

            align-items: center;

            justify-content: center;

            z-index: 55;
        }


        .logo img {

            width: 150px;
            height: 150px;

            object-fit: contain;

            display: block;
        }


        /* =================================================
           ACCOUNT BUTTON
        ================================================= */

        .contact-btn {

            display: inline-flex;

            align-items: center;

            justify-content: center;

            width: 45px;
            height: 45px;

            border: 1px solid #fff;

            border-radius: 50%;

            color: #fff;

            font-size: 16px;

            transition: .35s ease;

            z-index: 55;
        }


        .contact-btn:hover {

            background: #fff;

            color: #000;

        }


        /* =================================================
           SIDE MENU
        ================================================= */

        .side-menu {

            position: fixed;

            top: 0;

            left: -500px;

            width: 370px;

            height: 100vh;

            padding: 120px 45px 40px;

            background: #080808;

            border-right: 1px solid rgba(255,255,255,.45);

            z-index: 2000;

            overflow-y: auto;

            transition:
                left .45s cubic-bezier(.77,0,.175,1);
        }


        .side-menu.active {
            left: 0;
        }


        /* =================================================
           CLOSE BUTTON
        ================================================= */

        .close-btn {

            position: absolute;

            top: 28px;
            right: 30px;

            width: 42px;
            height: 42px;

            display: flex;

            align-items: center;

            justify-content: center;

            background: transparent;

            border: none;

            color: #fff;

            font-size: 35px;

            font-weight: 200;

            cursor: pointer;

            transition: .3s ease;
        }


        .close-btn:hover {

            transform: rotate(90deg);

            color: #ccc;
        }


        /* =================================================
           SIDE MENU NAV
        ================================================= */

        .side-menu nav {

            display: flex;

            flex-direction: column;
        }


        .side-menu nav a {

            display: block;

            padding: 18px 0;

            border-bottom:
                1px solid rgba(255,255,255,.08);

            color: #fff;

            font-size: 17px;

            letter-spacing: 2px;

            transition: .3s ease;
        }


        .side-menu nav a:first-child {

            border-top:
                1px solid rgba(255,255,255,.08);
        }


        .side-menu nav a:hover {

            padding-left: 10px;

            color: #ddd;
        }


        /* =================================================
           OVERLAY
        ================================================= */

        .menu-overlay {

            position: fixed;

            inset: 0;

            background: rgba(0,0,0,.72);

            z-index: 1500;

            opacity: 0;

            visibility: hidden;

            pointer-events: none;

            transition: .35s ease;
        }


        .menu-overlay.active {

            opacity: 1;

            visibility: visible;

            pointer-events: auto;
        }


        /* =================================================
           TERMS PAGE
        ================================================= */

        .terms-page {

            max-width: 1100px;

            margin: 0 auto;

            padding:
                180px 30px 100px;
        }


        .terms-header {

            padding-bottom: 50px;

            border-bottom:
                1px solid #292929;
        }


        .terms-label {

            display: inline-block;

            margin-bottom: 20px;

            color: #bdbdbd;

            font-size: 12px;

            letter-spacing: 4px;

            text-transform: uppercase;
        }


        .terms-header h1 {

            font-size:
                clamp(45px, 7vw, 82px);

            line-height: 1;

            font-weight: 300;

            margin-bottom: 25px;
        }


        .terms-header h1 span {

            color: #bdbdbd;
        }


        .terms-header p {

            max-width: 700px;

            color: #999;

            font-size: 15px;

            line-height: 1.8;
        }


        /* =================================================
           TERMS CONTENT
        ================================================= */

        .terms-content {

            padding-top: 55px;
        }


        .terms-section {

            margin-bottom: 55px;

            padding-bottom: 35px;

            border-bottom:
                1px solid #181818;
        }


        .terms-section:last-child {

            border-bottom: none;
        }


        .terms-section h2 {

            margin-bottom: 18px;

            color: #fff;

            font-size: 25px;

            font-weight: 400;

            letter-spacing: .5px;
        }


        .terms-section h2 span {

            color: #777;

            font-size: 13px;

            margin-right: 12px;

            letter-spacing: 2px;
        }


        .terms-section p {

            max-width: 900px;

            margin-bottom: 15px;

            color: #999;

            font-size: 15px;

            line-height: 1.9;
        }


        .terms-section ul {

            max-width: 900px;

            padding-left: 22px;

            margin-top: 15px;
        }


        .terms-section li {

            margin-bottom: 12px;

            color: #999;

            font-size: 15px;

            line-height: 1.8;
        }


        .terms-section strong {

            color: #ddd;

            font-weight: 500;
        }


        /* =================================================
           LAST UPDATED
        ================================================= */

        .terms-updated {

            margin-top: 20px;

            color: #666;

            font-size: 12px;

            letter-spacing: 1px;
        }


        /* =================================================
           CONTACT BOX
        ================================================= */

        .terms-contact {

            margin-top: 60px;

            padding: 35px;

            background: #0b0b0b;

            border: 1px solid #292929;
        }


        .terms-contact h3 {

            margin-bottom: 12px;

            color: #fff;

            font-size: 22px;

            font-weight: 400;
        }


        .terms-contact p {

            margin: 0;

            color: #888;

            font-size: 14px;

            line-height: 1.8;
        }


        .terms-contact a {

            color: #ddd;

            text-decoration: none;
        }


        .terms-contact a:hover {

            color: #fff;

        }


        /* =================================================
           MOBILE
        ================================================= */

        @media (max-width: 650px) {

            .main-header {

                height: 80px;

                padding: 0 18px;
            }


            .main-header::after {

                left: 18px;
                right: 18px;
            }


            .logo img {

                width: 100px;
                height: 100px;
            }


            .menu-btn {

                width: 75px;

                height: 36px;

                padding-left: 30px;

                font-size: 9px;
            }


            .menu-btn span {

                width: 20px;
            }


            .contact-btn {

                width: 40px;
                height: 40px;

                font-size: 14px;
            }


            .side-menu {

                left: -90%;

                width: 85%;

                padding:
                    100px 30px 30px;
            }


            .side-menu.active {

                left: 0;
            }


            .side-menu nav a {

                padding: 16px 0;

                font-size: 15px;
            }


            .close-btn {

                top: 22px;

                right: 22px;

                font-size: 32px;
            }


            .terms-page {

                padding:
                    135px 22px 70px;
            }


            .terms-header {

                padding-bottom: 35px;
            }


            .terms-header h1 {

                font-size: 48px;
            }


            .terms-header p {

                font-size: 14px;
            }


            .terms-content {

                padding-top: 40px;
            }


            .terms-section {

                margin-bottom: 40px;

                padding-bottom: 28px;
            }


            .terms-section h2 {

                font-size: 21px;

                line-height: 1.4;
            }


            .terms-section p,
            .terms-section li {

                font-size: 14px;

                line-height: 1.8;
            }


            .terms-contact {

                padding: 25px;

                margin-top: 40px;
            }

        }


        @media (max-width: 380px) {

            .terms-header h1 {

                font-size: 42px;
            }

            .terms-page {

                padding-left: 18px;
                padding-right: 18px;
            }

        }

    </style>

</head>


<body>


<!-- =================================================
     HEADER
================================================= -->

<header class="main-header">

    <button
        class="menu-btn"
        id="menuBtn"
        aria-label="Open Menu">

        <span></span>
        <span></span>
        <span></span>

    </button>


    <a href="index.php" class="logo">

        <img
            src="assets/images/logo.png"
            alt="Monarch Connect">

    </a>


    <a
        href="https://monarchconnect.co.in/account/"
        class="contact-btn"
        aria-label="Account">

        <i class="fa fa-user"></i>

    </a>

</header>


<!-- =================================================
     SIDE MENU
================================================= -->

<div
    class="side-menu"
    id="sideMenu">

    <button
        class="close-btn"
        id="closeBtn"
        aria-label="Close Menu">

        &times;

    </button>


    <nav>

        <a href="index.php">
            Home
        </a>

        <a href="about.php">
            About
        </a>

        <a href="index.php#services">
            Services
        </a>

        <a href="index.php#projects">
            Our Work
        </a>

        <a href="index.php#insights">
            Insights
        </a>

        <a href="index.php#news">
            Newsroom
        </a>

        <a href="blogs.php">
            Blog
        </a>

        <a href="contact.php">
            Contact
        </a>

    </nav>

</div>


<div
    class="menu-overlay"
    id="menuOverlay">
</div>


<!-- =================================================
     TERMS & CONDITIONS
================================================= -->

<main class="terms-page">

    <div class="terms-header">

        <span class="terms-label">
            Monarch Connect
        </span>

        <h1>
            Terms & <span>Conditions</span>
        </h1>

        <p>
            These Terms & Conditions govern your use of the Monarch Connect
            website and the services, information and resources made
            available through it. By accessing or using this website,
            you agree to comply with these terms.
        </p>

        <div class="terms-updated">
            Last Updated: 07 October 2026
        </div>

    </div>


    <div class="terms-content">


        <!-- 01 -->

        <section class="terms-section">

            <h2>
                <span>01</span>
                Acceptance of Terms
            </h2>

            <p>
                By accessing, browsing or using the Monarch Connect website,
                you acknowledge that you have read, understood and agreed
                to these Terms & Conditions. If you do not agree with any
                part of these terms, please discontinue use of the website.
            </p>

        </section>


        <!-- 02 -->

        <section class="terms-section">

            <h2>
                <span>02</span>
                About Monarch Connect
            </h2>

            <p>
                Monarch Connect provides an online platform for presenting
                information, services, projects, business opportunities,
                professional connections and related resources.
            </p>

            <p>
                The information available on the website is provided for
                general informational and business purposes and may be
                updated, changed or removed at any time without prior notice.
            </p>

        </section>


        <!-- 03 -->

        <section class="terms-section">

            <h2>
                <span>03</span>
                Website Use
            </h2>

            <p>
                You agree to use this website only for lawful purposes and
                in a manner that does not interfere with the operation,
                security or availability of the website.
            </p>

            <ul>

                <li>
                    You must not use the website for any unlawful or
                    fraudulent purpose.
                </li>

                <li>
                    You must not attempt to gain unauthorized access to
                    any account, server or system connected to the website.
                </li>

                <li>
                    You must not introduce malicious software, harmful code
                    or any other technology that could damage the website.
                </li>

                <li>
                    You must not copy, reproduce or redistribute website
                    content without appropriate authorization.
                </li>

            </ul>

        </section>


        <!-- 04 -->

        <section class="terms-section">

            <h2>
                <span>04</span>
                Intellectual Property
            </h2>

            <p>
                Unless otherwise stated, the content of this website,
                including text, graphics, logos, images, designs, layouts,
                branding and other materials, is owned by or licensed to
                Monarch Connect.
            </p>

            <p>
                You may view and use the website for personal or legitimate
                business purposes, but you may not reproduce, modify,
                distribute, publish or commercially exploit protected
                content without prior written permission.
            </p>

        </section>


        <!-- 05 -->

        <section class="terms-section">

            <h2>
                <span>05</span>
                User Information
            </h2>

            <p>
                Where you voluntarily provide information through the
                website, such as your name, email address, phone number,
                business information or other details, you agree that the
                information provided is accurate and belongs to you or that
                you have appropriate authority to provide it.
            </p>

        </section>


        <!-- 06 -->

        <section class="terms-section">

            <h2>
                <span>06</span>
                Third-Party Links
            </h2>

            <p>
                The website may contain links to third-party websites,
                services or resources. These links are provided for
                convenience and informational purposes.
            </p>

            <p>
                Monarch Connect does not necessarily control or endorse
                third-party websites and is not responsible for their
                content, availability, policies or practices.
            </p>

        </section>


        <!-- 07 -->

        <section class="terms-section">

            <h2>
                <span>07</span>
                Accuracy of Information
            </h2>

            <p>
                We make reasonable efforts to keep information on the
                website useful and up to date. However, Monarch Connect
                does not guarantee that all information will always be
                complete, accurate, current or free from errors.
            </p>

        </section>


        <!-- 08 -->

        <section class="terms-section">

            <h2>
                <span>08</span>
                Availability of Website
            </h2>

            <p>
                We may modify, suspend, restrict or discontinue any part
                of the website at any time, including for maintenance,
                security updates or technical reasons.
            </p>

            <p>
                We do not guarantee that the website will always be
                available, uninterrupted or completely free from technical
                issues.
            </p>

        </section>


        <!-- 09 -->

        <section class="terms-section">

            <h2>
                <span>09</span>
                Limitation of Liability
            </h2>

            <p>
                To the extent permitted by applicable law, Monarch Connect
                shall not be liable for any direct, indirect, incidental,
                consequential or other losses arising from your use of,
                or inability to use, the website or its content.
            </p>

        </section>


        <!-- 10 -->

        <section class="terms-section">

            <h2>
                <span>10</span>
                Privacy
            </h2>

            <p>
                Your use of the website may also be subject to our Privacy
                Policy. The Privacy Policy explains how information may be
                collected, used and protected when you interact with
                Monarch Connect.
            </p>

        </section>


        <!-- 11 -->

        <section class="terms-section">

            <h2>
                <span>11</span>
                Changes to These Terms
            </h2>

            <p>
                Monarch Connect reserves the right to update or modify
                these Terms & Conditions whenever necessary. Any updated
                version will be published on this page with a revised
                effective or updated date.
            </p>

            <p>
                Your continued use of the website after changes are posted
                constitutes acceptance of the updated terms.
            </p>

        </section>


        <!-- 12 -->

        <section class="terms-section">

            <h2>
                <span>12</span>
                Governing Law
            </h2>

            <p>
                These Terms & Conditions shall be governed by and interpreted
                in accordance with the applicable laws of India. Any dispute
                relating to the website or these terms shall be subject to
                the appropriate jurisdiction under applicable law.
            </p>

        </section>


        <!-- CONTACT -->

        <div class="terms-contact">

            <h3>
                Questions About These Terms?
            </h3>

            <p>
                If you have any questions, concerns or requests regarding
                these Terms & Conditions, please contact Monarch Connect
                through the contact information provided on our website.
            </p>

        </div>


    </div>

</main>


<!-- =================================================
     JAVASCRIPT
================================================= -->

<script>

const menuBtn =
    document.getElementById("menuBtn");

const closeBtn =
    document.getElementById("closeBtn");

const sideMenu =
    document.getElementById("sideMenu");

const menuOverlay =
    document.getElementById("menuOverlay");


menuBtn.addEventListener("click", () => {

    sideMenu.classList.add("active");

    menuOverlay.classList.add("active");

});


closeBtn.addEventListener("click", () => {

    sideMenu.classList.remove("active");

    menuOverlay.classList.remove("active");

});


menuOverlay.addEventListener("click", () => {

    sideMenu.classList.remove("active");

    menuOverlay.classList.remove("active");

});

</script>


<!-- =================================================
     YOUR EXISTING FOOTER
     YAHAN APNA FOOTER CODE PASTE KARNA
================================================= -->


</body>

</html>

<!-- =========================================================
     FOOTER
========================================================= -->

<footer class="main-footer">

    <div class="footer-main">

        <!-- ================= BRAND ================= -->

        <div class="footer-brand">

            <a href="/index.php" class="footer-logo">

                <img
                    src="/assets/images/logo.png"
                    alt="Monarch Connect Logo"
                >

            </a>

            <p>
                Make Your Own Mark With Monarch.
                Building ideas, creating possibilities
                and turning visions into reality.
            </p>

            <div class="footer-social">

                <a href="#" aria-label="Instagram">
                   <i class="fa fa-instagram"></i>
                </a>

                <a href="#" aria-label="Facebook">
                   <i class="fa fa-facebook"></i>
                </a>

                <a href="#" aria-label="YouTube">
                    <i class="fa fa-youtube"></i>
                </a>

                <a href="#" aria-label="LinkedIn">
                   <i class="fa fa-linkedin"></i>
                </a>

            </div>

        </div>



        <!-- ================= QUICK LINKS ================= -->

        <div class="footer-column">

            <h3>QUICK LINKS</h3>

            <a href="index.php">Home</a>

            <a href="about.php">About</a>

            <a href="#services">Services</a>

            <a href="#work">Our Work</a>

            <a href="contact.php">Contact</a>

        </div>



        <!-- ================= SERVICES ================= -->

        <div class="footer-column">

            <h3>SERVICES</h3>

            <a href="/our-services.php">Construction</a>
            <a href="/read.php">Read Me</a>

        </div>



        <!-- ================= CONTACT ================= -->

        <div class="footer-column footer-contact">

            <h3>CONTACT</h3>

            <a href="tel:+91 8800391355">
                +91 8800391355
            </a>

            <a href="monarch@info.monarchconnect.co.in">
                monarch@info.monarchconnect.co.in
            </a>

            <p>
                India
            </p>

            <a
                href="contact.php"
                class="footer-contact-btn"
            >
                GET IN TOUCH
                <span>→</span>
            </a>

        </div>

    </div>



    <!-- ================= FOOTER LINE ================= -->

    <div class="footer-line"></div>



    <!-- ================= BOTTOM ================= -->

    <div class="footer-bottom">

        <p>
            © <span id="footerYear"></span>
            Monarch Connect. All Rights Reserved.    &nbsp;<spna style="color:black"> Developed By Parvez Ahmad (<a href="https://www.google.com/search?q=parvez3737&oq=Parvez3737&gs_lcrp=EgZjaHJvbWUqBggAEEUYOzIGCAAQRRg7MgcIARAAGO8FMgcIAhAAGO8FMgcIAxAAGO8FMgcIBBAAGO8FMgcIBRAAGO8F0gEIMzQ5MmowajeoAgiwAgHxBRLQ5u5pQtVN8QUS0ObuaULVTQ&sourceid=chrome&source=chrome.ob&ie=UTF-8">Parvez3737</spna></a>
        </p>

        <div class="footer-bottom-links">

            <a href="privacy-policy.php">
                Privacy Policy
            </a>

            <a href="terms-and-conditions.php">
                Terms & Conditions
            </a>

        </div>

    </div>

</footer>
<style>/* =========================================================
   PREMIUM FOOTER — BLACK + WHITE + LIGHT GREY
========================================================= */

.main-footer {
    position: relative;
    background: #050505;
    color: #ffffff;
    padding: 85px 7% 25px;
    overflow: hidden;
}

/* =========================================================
   TOP LIGHT-GREY LINE
========================================================= */

.main-footer::before {
    content: "";
    position: absolute;
    top: 0;
    left: 7%;
    right: 7%;
    height: 1px;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(235,235,235,.75),
        transparent
    );
}

/* =========================================================
   FOOTER MAIN
========================================================= */

.footer-main {
    max-width: 1300px;
    margin: auto;
    display: grid;
    grid-template-columns: 2fr 1fr 1fr 1.3fr;
    gap: 60px;
}

/* =========================================================
   BRAND
========================================================= */

.footer-brand {
    max-width: 340px;
}

.footer-logo {
    display: inline-block;
    margin-bottom: 22px;
}

.footer-logo img {
    width: 125px;
    height: 125px;
    object-fit: contain;
    display: block;
}

.footer-brand > p {
    max-width: 320px;
    margin: 0;
    color: #a6a6a6;
    font-size: 13px;
    line-height: 1.9;
    letter-spacing: .4px;
}

/* =========================================================
   SOCIAL
========================================================= */

.footer-social {
    display: flex;
    gap: 10px;
    margin-top: 28px;
}

.footer-social a {
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;

    border: 1px solid rgba(210,210,210,.45);

    color: #e6e6e6;
    font-size: 15px;
    letter-spacing: 1px;
    text-decoration: none;

    transition: all .3s ease;
}

.footer-social a:hover {
    background: #ffffff;
    border-color: #ffffff;
    color: #000000;
    transform: translateY(-4px);
}

/* =========================================================
   COLUMNS
========================================================= */

.footer-column {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
}

.footer-column h3 {
    position: relative;
    margin: 12px 0 28px;

    color: #f5f5f5;
    font-size: 11px;
    font-weight: 400;
    letter-spacing: 4px;
}

.footer-column h3::after {
    content: "";
    display: block;
    width: 25px;
    height: 1px;
    margin-top: 11px;

    background: #d0d0d0;

    transition: width .3s ease;
}

.footer-column:hover h3::after {
    width: 45px;
}

.footer-column > a {
    margin-bottom: 14px;

    color: #9a9a9a;
    font-size: 15px;
    text-decoration: none;

    transition:
        color .3s ease,
        transform .3s ease;
}

.footer-column > a:hover {
    color: #ffffff;
    transform: translateX(5px);
}

/* =========================================================
   CONTACT
========================================================= */

.footer-contact p {
    margin: 0 0 22px;
    color: #999999;
    font-size: 14px;
}

.footer-contact-btn {
    display: inline-flex !important;
    align-items: center;
    gap: 13px;

    margin-top: 5px;
    padding: 11px 18px;

    border: 1px solid rgba(225,225,225,.55);

    color: #eeeeee !important;

    font-size: 9px !important;
    letter-spacing: 2px;

    transition: all .3s ease !important;
}

.footer-contact-btn span {
    font-size: 16px;
    transition: transform .3s ease;
}

.footer-contact-btn:hover {
    background: #ffffff;
    border-color: #ffffff;
    color: #000000 !important;
    transform: translateX(0) !important;
}

.footer-contact-btn:hover span {
    transform: translateX(5px);
}

/* =========================================================
   LINE
========================================================= */

.footer-line {
    max-width: 1300px;
    height: 1px;
    margin: 65px auto 22px;

    background: linear-gradient(
        90deg,
        transparent,
        rgba(220,220,220,.16),
        transparent
    );
}

/* =========================================================
   BOTTOM
========================================================= */

.footer-bottom {
    max-width: 1300px;
    margin: auto;

    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
}

.footer-bottom p {
    margin: 0;
    color: #666666;
    font-size: 10px;
    letter-spacing: .5px;
}

.footer-bottom-links {
    display: flex;
    gap: 25px;
}

.footer-bottom-links a {
    color: #666666;
    font-size: 10px;
    text-decoration: none;
    transition: color .3s ease;
}

.footer-bottom-links a:hover {
    color: #ffffff;
}

/* =========================================================
   TABLET
========================================================= */

@media (max-width: 950px) {

    .main-footer {
        padding: 75px 5% 25px;
    }

    .footer-main {
        grid-template-columns: repeat(2, 1fr);
        gap: 50px 40px;
    }

    .footer-brand {
        max-width: 100%;
    }
}

/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 600px) {

    .main-footer {
        padding: 65px 25px 25px;
    }

    .main-footer::before {
        left: 25px;
        right: 25px;
    }

    .footer-main {
        grid-template-columns: 1fr;
        gap: 42px;
    }

    .footer-brand {
        max-width: 100%;
        text-align: center;
    }

    .footer-logo {
        margin-bottom: 18px;
    }

    .footer-logo img {
        width: 105px;
        height: 105px;
        margin: auto;
    }

    .footer-brand > p {
        margin: auto;
        font-size: 12px;
    }

    .footer-social {
        justify-content: center;
    }

    .footer-column {
        align-items: center;
        text-align: center;
    }

    .footer-column h3 {
        margin-top: 0;
    }

    .footer-column > a:hover {
        transform: translateY(-2px);
    }

    .footer-contact-btn {
        margin-top: 8px;
    }

    .footer-bottom {
        flex-direction: column;
        text-align: center;
        gap: 15px;
    }

    .footer-bottom-links {
        flex-wrap: wrap;
        justify-content: center;
        gap: 15px;
    }
    
}
.footer-bottom p a,
.footer-bottom p a:hover,
.footer-bottom p a:focus,
.footer-bottom p a:visited {
    text-decoration: none;
    color: inherit;
}
</style>
<script>
    javascript
/* =========================================================
   FOOTER YEAR
========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    const year =
        document.getElementById("footerYear");

    if (year) {

        year.textContent =
            new Date().getFullYear();

    }

});

</script>